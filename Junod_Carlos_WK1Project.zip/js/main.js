$(document).ready(function(){
    $('#modal').hide();
    $('.layer-modal').hide();
})

var form = $('#js-add-recipe');
var formButton = $('#js-add-recipe').find('button');

// creating recipe object
class Recipe{
    constuctor({title, preparation, rating}){
        this.title = title
        this.preparation = preparation
        this.rating = rating

        console.log('recipe was created');
    }
}


var myRecipe = new Recipe('cool recipe', 'easy to cook', '123')

console.log('-----------------------');
console.log(myRecipe);
console.log('-----------------------');

$(formButton).on('click', function(e){
    e.preventDefault()
    var nameRecipe = $('#recipe-name').val();
    var descRecipe = $('#recipe-desc').val();
    var starsRecipe= $('#recipe-stars').val();

    console.log("button was pressed");

    console.log("Name:" + nameRecipe);
    console.log("description:" + descRecipe);
    console.log("rating:" + starsRecipe);

    var newRecipe = new Recipe(nameRecipe, descRecipe, starsRecipe)

    console.log(newRecipe);
})




var myRecipes = (function() {
        var json = null;
        $.ajax({
            'async': false,
            'global': false,
            'url': "/js/myRecipes.json",
            'dataType': "json",
            'success': function (data) {
                json = data;
            }
        });
        return json;
    })();

//opening modal
$('#add').on('click', function(){
    $('#modal').delay(100).fadeIn();
    $('.layer-modal').fadeIn();
})

// closing modal
$('#close-button').on('click', function(){
    $(this).closest('#modal').fadeOut();
    $('.layer-modal').delay(100).fadeOut(function(){
        $(form).find('input').each(function(index, field){
            $(field).val('');
        })
    });
})

var stars = $('.stars');

//console.log(myRecipes);
